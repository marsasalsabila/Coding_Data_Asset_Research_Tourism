R4.7 RECONSTRUCTED GEMINI OUTPUT STABILITY — SUBMISSION EVIDENCE
Manuscript: Language Models and System Dynamics for Overtourism
Manuscript ID: ANNALE-D-26-00377
Packaged: 16 November 2026

CONTENTS
- 01_Gemini_First_Response_Exports: 10 first-response JSON texts reported by authors, 01–10.
- 02_Reconstructed_Prompt: reconstructed prompt and earlier protocol as text extracts.
- 03_Audit_Report: documented stability assessment as text extract.
- 04_Verification: JSON count inventory, CRC32 and SHA-256 of ZIP payload files,
  and reference-alignment summary.

The 10 JSON responses were read from the existing source archive and preserved as text
without rewriting variable or relationship content. All 10 parse successfully; together they
contain 69 variable instances and 65 relationship instances.

PROVENANCE / LIMITATIONS
- The Gemini source responses were author-supplied and described as first answers from
  independent New Chat sessions, without regeneration. Session logs and inference
  settings were not independently verified.
- The reconstructed prompt is NOT the original historical Gemini prompt. Original
  historical conversations are unavailable.
- The reconstruction-protocol document was drafted before the outputs were supplied:
  its template/pending status should not be confused with the later completed audit.
- The DOCX sources are provided as extracted plain text; the source DOCX binaries
  are not reproduced here. This repackaging does NOT claim byte-for-byte identity
  with the prior local ZIP package.
- The reference-alignment summary does NOT replace an independently adjudicated
  23 x 10 item-level coding matrix or underlying original source transcripts.
- 11/230 conservative near-equivalent construct comparisons and 0/260 strictly
  recovered historical directed links were reported. Broad thematic recurrence
  is not historical network reproduction or causal validation.

No Google Maps review-level dataset is included.
