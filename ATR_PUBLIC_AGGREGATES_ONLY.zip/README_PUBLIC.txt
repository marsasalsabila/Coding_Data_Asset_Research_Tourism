ATR research: PUBLIC AGGREGATE-ONLY supporting tables

Source: 25-destination Google Maps-derived research corpus (original kept private).
Source records: 100,162. Destination labels: 25.
Indonesian non-null texts: 99,473.
Eight original sustainability substring keywords selected: 9,469.

Files contain only aggregate statistics by destination or overall, and a counts-only audit.
NO reviewer names, review text, per-review rows, user IDs, profile links, or precise GPS.
This package is NOT a replacement for the original text corpus used in BERTopic.
The raw source and translation mapping are not made openly available here.
Access to the original raw data may be restricted by privacy and source/platform terms.
Do not claim a fully reproducible BERTopic execution from aggregate tables alone.
Review source licenses and consent/rights before publishing even derived outputs.

Note: keyword counts overlap and should not be summed to equal the selected-corpus count.
